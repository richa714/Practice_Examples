app.controller('NodeAngularFrameworkController', function($scope, $http,
		$location, $rootScope) {

	$scope.shopping = function() {
		console.log('inside view function');
		$scope.user = {
			"name" : "Richa",
			"id" : "827468"
		};
		$http({
			'url' : '/shopping',
			'method' : 'POST',
			'headers' : {
				'Content_Type' : 'application/json'
			},
			'data' : $scope.user
		}).success(function(data) {

			console.log('data retreived');
			$rootScope.user = data;
			console.log($rootScope.user);
			console.log($rootScope.user.id);

			$location.path("/shopping");

		}).error(function() {
			console.log('some error occured');
		});

	};

	$(document).ready(function() {

	});

});

app.controller('viewController',
		function($scope, $http, $location, $rootScope) {
			console.log('inside view controller');
			$http.get('/viewPg').success(function(data) {
				$scope.itemDetails = data;
				console.log("item details-- ");
				console.log($scope.itemDetails);
			}).error(function() {
				console.log("some error occurred while fetching data");
			});

		});

app.controller('viewMongoController',
		function($scope, $http, $location, $rootScope) {
			console.log('inside view controller');
			$http.get('/viewMongo').success(function(data) {
				$scope.itemDetails = data;
				console.log("item details-- ");
				console.log($scope.itemDetails);
			}).error(function() {
				console.log("some error occurred while fetching data");
			});

			$scope.mongoDelete=function(id)
			{
				$scope.deleteObject={};
				$scope.deleteObject.id=id;
				console.log("item to be deleted--  ",$scope.deleteObject);
				$http(
					{
					'url':'/deleteMongo',	
					'method':'post',
					'headers':{'Content-Type':'application/json'},
					'data':$scope.deleteObject					
					}).success(function(data)				
				{
						console.log("deleted successfully");
					console.log(data);
					
					$http.get('/viewMongo').success(function(data) {
						$scope.itemDetails = data;
						console.log("item details-- ");
						console.log($scope.itemDetails);
						$location.path('#delete');
					}).error(function() {
						console.log("some error occurred while fetching data");
					});
					
				})		
				.error(function()
				{
					console.log("some error occurred while deleting the data");
				});
				
				
				
			};

			
		});

app.controller('addController', function($scope, $http, $location, $rootScope) {
	console.log('inside add controller');
	$scope.item = {};

	$scope.addPg = function() {
		console.log('inside add function');
		console.log($scope.item);
		$http({
			'url' : '/addPg',
			'method' : 'POST',
			'headers' : {
				'Content_Type' : 'application/json'
			},
			'data' : $scope.item
		}).success(function(data) {
			console.log('data saved');
		}).error(function() {
			console.log('some error occured');
		});

	};
	$scope.addMongo = function() {
		console.log('inside add function');
		console.log($scope.item);
		$http({
			'url' : '/addMongo',
			'method' : 'POST',
			'headers' : {
				'Content_Type' : 'application/json'
			},
			'data' : $scope.item
		}).success(function(data) {
			console.log(data);
			console.log('data saved');

		}).error(function() {
			console.log('some error occured');
		});

	};
	
	
});
