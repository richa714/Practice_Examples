var app = angular.module('NodeAngularFrameworkApp', ['ngRoute']);
app.config(function($routeProvider) {
	//alert("inside routes");
	$routeProvider.when("/add", {
		templateUrl : "../HTML/add.html",
		controller:"addController"

	})
	.when("/viewPg", {
		templateUrl : "../HTML/view.html",
		controller:"viewController"

	})
	.when("/viewMongo", {
		templateUrl : "../HTML/view.html",
		controller:"viewMongoController"

	})
	.when("/updateMongo",
	{
		templateUrl:"../HTML/update.html",
		controller:"updateMongoContoller"
	})
	.when("/delete",
	{
	templateUrl:"../HTML/delete.html",
	controller:"viewMongoController",
		
	});
	
	
}

);