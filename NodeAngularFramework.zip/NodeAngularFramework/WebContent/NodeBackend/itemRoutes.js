var express = require('express');
var router = express.Router();
var bodyParser=require('body-parser');
router.use(bodyParser.json());
/*
 * // Middle ware that is specific to this router router.use(function
 * timeLog(req, res, next) { console.log('Time:', Date.now()); next(); });
 */


router.post('/addPg', function(req, res) {
	var pg = require("pg");
	var pgClient = new pg.Client({
		user : 'postgres',
		password : 'Apps12#',
		host : 'localhost',
		database : 'VSM'

	});
	console.log("getting request");
	//console.log(req.item);
	//console.log(req.data);
	//console.log(req.body.id);
	//console.log(req.body.item);
	//console.log(req);
	//console.log(pgClient);
	pgClient.connect();
	var query = pgClient.query(
			"Insert into item_details(id,name,description,rating,price) values($1,$2,$3,$4,$5)", [ req.body.id,
					req.body.name, req.body.description, req.body.rating,
					req.body.price ], function(err, result) {
				if (err)
					console.log("some error occurred" + err);
				else
					{
					console.log("data successfully inserted");
					res="success";
					}
			});
	console.log(query);
	return res;
});

router.get('/viewPg',function(req,res)
{
	var pg = require("pg");
	var pgClient = new pg.Client({
		user : 'postgres',
		password : 'Apps12#',
		host : 'localhost',
		database : 'VSM'

	});
	pgClient.connect();
	const
	results = [];
	var query = pgClient.query("Select * from item_details");
	query.on("row", function(row) {
		results.push(row);
	});
	query.on('end', function() {
		//pgClient.done();
		return res.json(results);
	});
	
});

router.get('/viewMongo',function(req,res)
{
	
	console.log("inside view Mongo");
var mongoClient=require("mongodb").MongoClient;
var result=[];
mongoClient.connect("mongodb://localhost:27017/practice",function(err,db){
	if(err){
		console.log("Some error occurred while connecting to database");
		}
	else
		{
		console.log("inside else");
		var collection=db.collection("item_details");
		console.log(collection);
		collection.find().toArray(function(err,docs)
		{
			
		console.log("document length"+docs.length);
		res.json(docs);
		docs.forEach(function(doc)
		{
			console.log(doc);
		});
		});
		//result="success";
		//console.log(result);
		//console.log(data.json);
		}
});	
return res;	
});
router.post('/addMongo', function(req, res) {
	console.log("getting request");
	console.log(req.body.id);
	var result=[];
	// connecting to DB
	var mongoClient = require("mongodb").MongoClient;
	mongoClient.connect("mongodb://localhost:27017/practice",
			function(err, db) {
				if (err) {
					console.log("some error occurred while connecting to database");
				}
				else
					{
				var collection = db.collection("item_details");
				collection.insert(req.body);
				//console.log("inside else");
				result="success";
					}
			});
	//console.log(res);
	return res.json(result);
	});

router.post('/deleteMongo',function(req,res)
{
console.log("in delete mongo");
console.log(req.body.id);
var mongoClient=require("mongodb").MongoClient;


mongoClient.connect("mongodb://localhost:27017/practice",function(err,db)
		{
	
	if(err){
		console.log("some eror occured while connecting to database");
	}
	else
		{
		var collection=db.collection("item_details");
		collection.remove({"id":req.body.id},function(err,result)
		{
			if(err)
				{
				console.log("this document cannot be deleted");
				}
			else
				{
				console.log(result);
				result="Document deleted successfully";
				res.json(result);
				}
		});
		}
		});
});




router.post('/updateMongo',function(req,res)
{
	console.log("update request");
console.log('the record to be updated'+req.body.id);

var mongoClient=require("mongodb").MongoClient;

mongoClient.connect("mongodb://localhost:27017/practice",function(err,db)
{
	
	if(err)
		{
		console.log('some error while connecting to database');
		}
	else
		{
		var collection=db.collection("item_details");
		collection.update({id:req.body.id},{$set:{"name":"Glass"}});
		
		res.json("Record updated successfully");
		}
	});

	

});


module.exports = router;