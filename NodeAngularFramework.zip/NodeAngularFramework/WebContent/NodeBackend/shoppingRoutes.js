var express = require('express');
var router = express.Router();

/*
 * // Middle ware that is specific to this router router.use(function
 * timeLog(req, res, next) { console.log('Time:', Date.now()); next(); });
 */

router.post('/shopping', function(req, res) {
	console.log("getting request");
	console.log(req.body);
	// connecting to DB
	var pg = require("pg");
	// var connString = "pg://postgres:apps12\#@localhost:5432/VSM";
	// console.log("creating postgres connection");
	// console.log(connString);
	var pgClient = new pg.Client({
		user : 'postgres',
		password : 'Apps12#',
		host : 'localhost',
		database : 'VSM'

	});
	console.log(pgClient);
	pgClient.connect();
	const
	results = [];
	const
	data = {};
	var query = pgClient.query("select * from shopping_categories limit 1");
	query.on("row", function(row) {
		results.push(row);
	});

	query.on('end', function() {
		return res.json(results);
	});
});
module.exports = router;
