package practice;

import java.lang.reflect.Method;

public class ReflectionDemo {
	public static void main(String args[])
	{
		System.out.println("in main");
		Class c=ReflectionBean.class;
		System.out.println("class name-- "+c.getName());
		Method[] m=c.getMethods();
		//------methods---------
		for(Method method:m)
		{
			System.out.println("method names-- "+method.getName());
		}
		//-----package-------
		Package p=c.getPackage();
		System.out.println("package-- "+p.getName());
		//-----superclass-----------
		System.out.println("super class-- "+c.getSuperclass());
		//-------interfaces----------
		Class[] i=c.getInterfaces();
		System.out.println("interface length-- "+i.length);
		for(Class interfaces:i)
		{
			System.out.println("interfaces-- "+interfaces.getName());
		}
		
				
	}

}
