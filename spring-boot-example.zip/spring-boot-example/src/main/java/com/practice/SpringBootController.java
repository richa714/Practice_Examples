package com.practice;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SpringBootController {
	/*@RequestMapping("/trial")
	public String hello()
	{
		return "Hello";
	}*/
	@RequestMapping("/trial")
	public String hello()
	{
		System.out.println("in hello");
		return "Hello";
	}
	
	@RequestMapping("/")
	public String trial()
	{
		System.out.println("in trial");
		return "Default Page";
	}
}
